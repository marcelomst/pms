class Alumno
    attr_accessor :nombre, :curso
    
    def initialize nombre, curso
        @nombre = nombre
        @curso = curso
    end
end

class AlumnosController < ApplicationController
  def calificar
    @ana = Alumno.new "Ana", "Gnosis"
    @alumno = "#{@ana.nombre} cursa #{@ana.curso}"
  end
end
