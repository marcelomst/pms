require 'date'

class Reserva
    attr_accessor :nombre, :codigo, :fechainicio, :fechafin, :arreglos
    
    def initialize nombre, codigo, fechainicio, fechafin, arreglos
        @nombre = nombre
        @codigo = codigo
        @fechainicio = fechainicio
        @fechafin = fechafin
        @arreglos = arreglos
    end
end

class ReservasController < ApplicationController
    def crear
        dfrom = Date.new(2016,10,19)
        dto = Date.new(2016,10,20)
        arreglos = {'203'=>2}
        @ana = Reserva.new "Ana", 1, dfrom, dto, arreglos 
        @arreglo203 = "#{@ana.nombre} cod:#{@ana.codigo} cant:#{@ana.arreglos['203']}"
    end
end
