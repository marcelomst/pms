class Panel1Controller < ApplicationController
  def deplegar1
  end
end
