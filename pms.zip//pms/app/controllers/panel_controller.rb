class PanelController < ApplicationController
  def deplegar
  end
end
