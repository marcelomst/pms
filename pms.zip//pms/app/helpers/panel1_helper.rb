module Panel1Helper
end
