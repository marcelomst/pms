class Alumno
#    attr_accessor :nombre
    
    def initialize nombre, curso
        @nombre = nombre
        @curso = curso
    end
end