require 'test_helper'

class PanelControllerTest < ActionController::TestCase
  test "should get deplegar" do
    get :deplegar
    assert_response :success
  end

end
