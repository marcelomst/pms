require 'test_helper'

class Panel1ControllerTest < ActionController::TestCase
  test "should get deplegar1" do
    get :deplegar1
    assert_response :success
  end

end
