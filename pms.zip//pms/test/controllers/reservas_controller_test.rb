require 'test_helper'

class ReservasControllerTest < ActionController::TestCase
  test "should get crear" do
    get :crear
    assert_response :success
  end

end
