require 'test_helper'

class AlumnosControllerTest < ActionController::TestCase
  test "should get calificar" do
    get :calificar
    assert_response :success
  end

end
